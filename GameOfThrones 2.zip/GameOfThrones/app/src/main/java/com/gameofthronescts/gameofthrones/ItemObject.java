package com.gameofthronescts.gameofthrones;

/**
 * Created by koundinya on 6/23/17.
 */

public class ItemObject {

    private String contents;
    public ItemObject(String contents) {
        this.contents = contents;
    }
    public String getContents() {
        return contents;
    }
}
