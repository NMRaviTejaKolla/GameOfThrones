package com.gameofthronescts.gameofthrones;

import android.app.Activity;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.widget.TextView;

/**
 * Created by koundinya on 6/23/17.
 */

public class SeasonDetailsActivity extends AppCompatActivity {



    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.season_details_activity);

        TextView  textViewYear = (TextView) findViewById(R.id.textView_Year);
        textViewYear.setText("");
        TextView  textViewYearValue = (TextView) findViewById(R.id.textView_Year_Value);
        textViewYearValue.setText("");


    }
}
